#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <algorithm>
#include "Headers.h"
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

void vector1();
void vector2();

int main(int argc, char** argv){

	string filename = "HeaderFunctions.h";
	ifstream file(filename.c_str());
	if (!file) { 
		cout < "ERROR: Cannot Open File!"; 
	}	
	void function1();
	{
		vector<int> v1;
		vector<int> v2;
		vector<int> sums;
		vector<int> products;
		int i;
		int j;
		int a;
		int b;
		void vector1();{
			cout << "PLease enter integer values for vector 1: " << "\n";
			for (i = 0; i < 10 ; i++){
			cin >> a;
			v1.push_back(a);
			}
			cout << "\n";
		}
		
		void vector2();{
			cout << "PLease enter integer values for vector 2: " << "\n";
			for (j = 0; j < 10; j++){
				cin >> b;
				v2.push_back(b);
			}
			cout << "\n";
		}
		void vectorSum();{
			for (i = 0; i < 10; i++){
				cout << v1[i] + v2[i] << ", ";
			}
		}
		cout << "\n";
		
		void vectorProduct();{
			for (i = 0; i < 10; i++)
				cout << v1[i] * v2[i] << ", ";
		} cout << "\n"; 
		cout << "\n";
		for (i = 0; i < 10; i++){
			cout << v1[i] << ", ";
		} cout << "\n";
		for (j = 0; j < 10; j++){
			cout << v2[j] << ", ";
		} cout << "\n";
		for (i = 0; i < 10; i++){
			cout << v1[i] + v2[i] << ", ";
		} cout << "\n";
		for (i = 0; i < 10; i++){
			cout << v1[i] * v2[i] << ", ";
		} cout << "\n";
	}
	void function2(); {
		
		vector<int> v3;
		int i;
		int c;
		
		void vector3( );{
			cout << "Please enter 10 integer values: " << "\n";
			for (i = 0; i < 10; i++){
				cin >> c;
				v3.push_back(c);
			}
			cout << v3[i] << ", "; 
			
			rotate(v3.begin(), v3.begin()+3, v3.end());
			for (i = 0; i < 10; i++){
				cout << v3[i];
			}
				
		}
		
	}
	return 0;
}
