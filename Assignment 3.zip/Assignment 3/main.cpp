#include <iostream>
#include "Headers.h"
#include "Functions.cpp"
/* run this program using the console pauser or add your own getch, system("pause") or input loop */


	void function1();
	void function2();
